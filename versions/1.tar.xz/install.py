run("cp /tmp/1984/1984.py /py/1984.py")
